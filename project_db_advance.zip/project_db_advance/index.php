<?php
// index.php - الإصدار المعدّل مع إصلاح المشاكل
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// الاتصال بقاعدة البيانات
$host = "localhost";
$username = "root";
$password = "";
$database = "budget_system";

$conn = mysqli_connect($host, $username, $password);

if (!$conn) {
    die("<div style='background:#f8d7da; color:#721c24; padding:20px; margin:20px; border-radius:8px;'>
            <h3>❌ خطأ في الاتصال بقاعدة البيانات</h3>
            <p>تأكد من تشغيل MySQL في XAMPP Control Panel</p>
            <p>تفاصيل: " . mysqli_connect_error() . "</p>
         </div>");
}

// إنشاء قاعدة البيانات والجدول
$create_db = "CREATE DATABASE IF NOT EXISTS $database 
              CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
mysqli_query($conn, $create_db);
mysqli_select_db($conn, $database);

$create_table = "CREATE TABLE IF NOT EXISTS budgets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    total_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    spent_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    progress INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active',
    tags TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (!mysqli_query($conn, $create_table)) {
    die("خطأ في إنشاء الجدول: " . mysqli_error($conn));
}

mysqli_set_charset($conn, "utf8mb4");

// دوال CRUD
function get_all_budgets($conn) {
    $sql = "SELECT * FROM budgets ORDER BY created_at DESC";
    return mysqli_query($conn, $sql);
}

function get_budget($conn, $id) {
    $id = intval($id);
    $sql = "SELECT * FROM budgets WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }
    return null;
}

function insert_budget($conn, $data) {
    $title = mysqli_real_escape_string($conn, $data['title']);
    $description = mysqli_real_escape_string($conn, $data['description'] ?? '');
    $total_amount = floatval($data['total_amount']);
    $spent_amount = floatval($data['spent_amount'] ?? 0);
    $start_date = mysqli_real_escape_string($conn, $data['start_date']);
    $end_date = mysqli_real_escape_string($conn, $data['end_date']);
    $tags = mysqli_real_escape_string($conn, $data['tags'] ?? '');
    $status = mysqli_real_escape_string($conn, $data['status'] ?? 'active');
    
    $progress = $total_amount > 0 ? min(100, intval(($spent_amount / $total_amount) * 100)) : 0;
    
    $sql = "INSERT INTO budgets (title, description, total_amount, spent_amount, 
            start_date, end_date, progress, status, tags) 
            VALUES ('$title', '$description', $total_amount, $spent_amount,
            '$start_date', '$end_date', $progress, '$status', '$tags')";
    
    if (mysqli_query($conn, $sql)) {
        return mysqli_insert_id($conn);
    }
    return false;
}

function update_budget($conn, $id, $data) {
    $id = intval($id);
    
    $title = mysqli_real_escape_string($conn, $data['title']);
    $description = mysqli_real_escape_string($conn, $data['description'] ?? '');
    $total_amount = floatval($data['total_amount']);
    $spent_amount = floatval($data['spent_amount'] ?? 0);
    $start_date = mysqli_real_escape_string($conn, $data['start_date']);
    $end_date = mysqli_real_escape_string($conn, $data['end_date']);
    $tags = mysqli_real_escape_string($conn, $data['tags'] ?? '');
    $status = mysqli_real_escape_string($conn, $data['status'] ?? 'active');
    
    $progress = $total_amount > 0 ? min(100, intval(($spent_amount / $total_amount) * 100)) : 0;
    
    $sql = "UPDATE budgets SET 
            title = '$title',
            description = '$description',
            total_amount = $total_amount,
            spent_amount = $spent_amount,
            start_date = '$start_date',
            end_date = '$end_date',
            progress = $progress,
            status = '$status',
            tags = '$tags',
            updated_at = CURRENT_TIMESTAMP
            WHERE id = $id";
    
    return mysqli_query($conn, $sql);
}

function delete_budget($conn, $id) {
    $id = intval($id);
    $sql = "DELETE FROM budgets WHERE id = $id";
    return mysqli_query($conn, $sql);
}

// إضافة بيانات تجريبية إذا كانت الجداول فارغة
$check = mysqli_query($conn, "SELECT COUNT(*) as count FROM budgets");
$row = mysqli_fetch_assoc($check);
if ($row['count'] == 0) {
    $sample_data = [
        [
            'title' => 'Product Designer',
            'description' => 'مصمم منتجات',
            'total_amount' => 520000,
            'spent_amount' => 312000,
            'start_date' => '2024-05-31',
            'end_date' => '2024-12-31',
            'tags' => 'UI/UX Designer, Visual Designer, Design Lead, +7 سنوات خبرة'
        ],
        [
            'title' => 'Human Resources',
            'description' => 'الموارد البشرية',
            'total_amount' => 120000,
            'spent_amount' => 34500,
            'start_date' => '2024-05-31',
            'end_date' => '2024-12-31',
            'tags' => 'HR, Recruitment, Training'
        ],
        [
            'title' => 'Brand Designer',
            'description' => 'مصمم علامة تجارية',
            'total_amount' => 260000,
            'spent_amount' => 78000,
            'start_date' => '2024-01-01',
            'end_date' => '2024-12-31',
            'tags' => 'Branding, Logo Design, Visual Identity'
        ]
    ];
    
    foreach ($sample_data as $data) {
        insert_budget($conn, $data);
    }
}

$budgets_result = get_all_budgets($conn);

// عرض رسائل النجاح/الخطأ
$message = '';
$message_type = '';
if (isset($_GET['success'])) {
    $message_type = 'success';
    $msg = $_GET['success'];
    if ($msg == 'insert') $message = 'تمت إضافة الميزانية بنجاح!';
    elseif ($msg == 'update') $message = 'تم تحديث الميزانية بنجاح!';
    elseif ($msg == 'delete') $message = 'تم حذف الميزانية بنجاح!';
} elseif (isset($_GET['error'])) {
    $message_type = 'error';
    $msg = $_GET['error'];
    if ($msg == 'not_found') $message = 'الميزانية غير موجودة!';
    elseif ($msg == 'delete_failed') $message = 'فشل حذف الميزانية!';
    else $message = htmlspecialchars($msg);
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الميزانية - Organization Settings</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-bg: #f9fafb;
            --white: #ffffff;
            --sidebar-bg: #ffffff;
            --primary-green: #007a5a;
            --dark-green: #00674d;
            --text-primary: #1f2937;
            --text-secondary: #6b7280;
            --text-muted: #9ca3af;
            --border-color: #e5e7eb;
            --light-border: #f3f4f6;
            --progress-green: #10b981;
            --progress-orange: #f59e0b;
            --progress-red: #dc3545;
            --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }
        
        body {
            background: var(--primary-bg);
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .app-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* الشريط الجانبي */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            border-left: 1px solid var(--light-border);
            padding: 32px 24px;
            position: fixed;
            right: 0;
            top: 0;
            bottom: 0;
            overflow-y: auto;
        }
        
        .sidebar-header {
            margin-bottom: 40px;
        }
        
        .sidebar-header h2 {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 4px;
        }
        
        .sidebar-header p {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
        }
        
        .nav-menu {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            text-decoration: none;
            color: var(--text-secondary);
            border-radius: 12px;
            transition: all 0.2s ease;
            font-weight: 500;
            font-size: 15px;
        }
        
        .nav-item i {
            margin-left: 12px;
            width: 20px;
            text-align: center;
            font-size: 16px;
        }
        
        .nav-item.active {
            background: var(--white);
            color: var(--text-primary);
            font-weight: 600;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
        }
        
        .nav-item:hover:not(.active) {
            background: #f8f9fa;
            color: var(--text-primary);
        }
        
        /* المحتوى الرئيسي */
        .main-content {
            flex: 1;
            margin-right: 280px;
            padding: 40px;
            max-width: 1200px;
        }
        
        /* رأس الصفحة */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .page-title h1 {
            font-size: 30px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 8px;
        }
        
        .page-title p {
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .filter-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: var(--white);
            border: 1px dashed var(--border-color);
            border-radius: 8px;
            color: var(--text-secondary);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        
        .filter-btn:hover {
            border-color: var(--primary-green);
            color: var(--primary-green);
        }
        
        .header-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .export-btn {
            padding: 10px 20px;
            background: var(--white);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        
        .export-btn:hover {
            border-color: var(--primary-green);
            color: var(--primary-green);
        }
        
        .add-budget-btn {
            padding: 10px 20px;
            background: var(--primary-green);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }
        
        .add-budget-btn:hover {
            background: var(--dark-green);
        }
        
        /* بطاقات الميزانية */
        .budgets-grid {
            display: grid;
            gap: 24px;
        }
        
        .budget-card {
            background: var(--white);
            border-radius: 24px;
            padding: 24px;
            border: 1px solid var(--border-color);
            transition: transform 0.2s, box-shadow 0.2s;
            max-width: 800px;
        }
        
        .budget-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }
        
        .budget-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }
        
        .budget-title {
            flex: 1;
        }
        
        .budget-amount {
            font-size: 32px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 4px;
            line-height: 1.2;
        }
        
        .budget-name {
            font-size: 16px;
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        .budget-menu {
            color: var(--text-muted);
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: background 0.2s;
        }
        
        .budget-menu:hover {
            background: var(--light-border);
        }
        
        /* شريط التقدم */
        .progress-section {
            margin: 24px 0;
        }
        
        .progress-labels {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text-secondary);
        }
        
        .progress-percent {
            color: var(--progress-green);
        }
        
        .progress-bar {
            height: 8px;
            background: var(--light-border);
            border-radius: 10px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            border-radius: 10px;
            background: var(--progress-green);
            transition: width 0.3s ease;
        }
        
        .progress-fill.low { background: var(--progress-green); }
        .progress-fill.medium { background: var(--progress-orange); }
        .progress-fill.high { background: var(--progress-red); }
        
        /* تفاصيل الميزانية */
        .budget-details {
            display: grid;
            gap: 12px;
            margin: 20px 0;
        }
        
        .detail-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 14px;
        }
        
        .detail-label {
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        .detail-value {
            color: var(--text-primary);
            font-weight: 600;
        }
        
        /* الوسوم */
        .tags-container {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 20px;
        }
        
        .tag {
            background: var(--light-border);
            border: 1px solid var(--border-color);
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        /* رسائل التنبيه */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #d1fae5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }
        
        .alert-error {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #991b1b;
        }
        
        /* حالة عدم وجود بيانات */
        .empty-state {
            text-align: center;
            padding: 80px 40px;
            background: var(--white);
            border-radius: 24px;
            border: 1px solid var(--border-color);
            max-width: 800px;
        }
        
        .empty-state i {
            font-size: 64px;
            color: var(--border-color);
            margin-bottom: 24px;
        }
        
        .empty-state h3 {
            font-size: 20px;
            color: var(--text-primary);
            margin-bottom: 12px;
        }
        
        .empty-state p {
            color: var(--text-secondary);
            margin-bottom: 24px;
        }
        
        /* الأزرار */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            outline: none;
        }
        
        .btn-sm {
            padding: 8px 16px;
            font-size: 13px;
        }
        
        .btn-primary {
            background: var(--primary-green);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--dark-green);
        }
        
        .btn-secondary {
            background: var(--white);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
        }
        
        .btn-secondary:hover {
            border-color: var(--primary-green);
            color: var(--primary-green);
        }
        
        .btn-edit {
            background: var(--progress-orange);
            color: #212529;
        }
        
        .btn-edit:hover {
            background: #e0a800;
        }
        
        .btn-danger {
            background: var(--progress-red);
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .card-actions {
            display: flex;
            gap: 12px;
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid var(--border-color);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .app-container {
                flex-direction: column;
            }
            
            .sidebar {
                position: static;
                width: 100%;
                border-left: none;
                border-bottom: 1px solid var(--light-border);
            }
            
            .main-content {
                margin-right: 0;
                padding: 20px;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 16px;
            }
            
            .header-left, .header-right {
                width: 100%;
            }
            
            .card-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
<div class="app-container">
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>إعدادات المنظمة</h2>
            <p>Organization Settings</p>
        </div>
        
        <nav class="nav-menu">
            <a href="index.php" class="nav-item active">
                <i class="fa-solid fa-gear"></i>
                <span>عام</span>
            </a>
            
            <a href="#" class="nav-item">
                <i class="fa-solid fa-users"></i>
                <span>الأعضاء</span>
            </a>
            
            <a href="#" class="nav-item">
                <i class="fa-solid fa-briefcase"></i>
                <span>الخبراء</span>
            </a>
            
            <a href="index.php" class="nav-item active">
                <i class="fa-solid fa-dollar-sign"></i>
                <span>الميزانية</span>
            </a>
            
            <a href="#" class="nav-item">
                <i class="fa-solid fa-chart-line"></i>
                <span>التحليلات</span>
            </a>
        </nav>
    </div>
    
    <div class="main-content">
        <div class="page-header">
            <div class="header-left">
                <div class="page-title">
                    <h1>الميزانية</h1>
                    <p>إدارة جميع ميزانيات المنظمة</p>
                </div>
                <button class="filter-btn">
                    <i class="fa-solid fa-plus"></i> إضافة فلتر
                </button>
            </div>
            <div class="header-right">
                <button class="export-btn">تصدير</button>
                <a href="insert.php" class="add-budget-btn">
                    <i class="fa-solid fa-plus"></i> إضافة ميزانية
                </a>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <i class="fa-solid fa-<?php echo $message_type == 'success' ? 'check-circle' : 'exclamation-triangle'; ?>"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="budgets-grid">
            <?php if (mysqli_num_rows($budgets_result) > 0): ?>
                <?php while ($budget = mysqli_fetch_assoc($budgets_result)): 
                    $progress = $budget['progress'];
                    
                    // تحديد لون شريط التقدم
                    if ($progress >= 80) {
                        $progress_class = 'high';
                        $progress_color = '#dc3545';
                    } elseif ($progress >= 60) {
                        $progress_class = 'medium';
                        $progress_color = '#f59e0b';
                    } else {
                        $progress_class = 'low';
                        $progress_color = '#10b981';
                    }
                    
                    // تنسيق المبلغ
                    $formatted_amount = '$' . number_format($budget['total_amount']);
                    
                    // تنسيق التاريخ
                    $start_date_formatted = date('M d, Y', strtotime($budget['start_date']));
                    $end_date_formatted = date('M d, Y', strtotime($budget['end_date']));
                ?>
                <div class="budget-card">
                    <div class="budget-header">
                        <div class="budget-title">
                            <div class="budget-amount"><?php echo $formatted_amount; ?></div>
                            <div class="budget-name"><?php echo htmlspecialchars($budget['title']); ?></div>
                        </div>
                        <div class="budget-menu">
                            <i class="fa-solid fa-ellipsis-vertical"></i>
                        </div>
                    </div>
                    
                    <div class="progress-section">
                        <div class="progress-labels">
                            <span class="progress-percent" style="color: <?php echo $progress_color; ?>;">
                                <?php echo $progress; ?>%
                            </span>
                            <span><?php echo 100 - $progress; ?>%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill <?php echo $progress_class; ?>" style="width: <?php echo $progress; ?>%;"></div>
                        </div>
                    </div>
                    
                    <div class="budget-details">
                        <div class="detail-row">
                            <span class="detail-label">المبلغ الإجمالي</span>
                            <span class="detail-value">$<?php echo number_format($budget['total_amount']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">تاريخ البدء</span>
                            <span class="detail-value"><?php echo $start_date_formatted; ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">تاريخ الانتهاء</span>
                            <span class="detail-value"><?php echo $end_date_formatted; ?></span>
                        </div>
                    </div>
                    
                    <?php if (!empty($budget['tags'])): 
                        $tags = explode(',', $budget['tags']);
                    ?>
                    <div class="tags-container">
                        <?php foreach ($tags as $tag): 
                            $tag_trimmed = trim($tag);
                            if (!empty($tag_trimmed)):
                        ?>
                        <span class="tag"><?php echo htmlspecialchars($tag_trimmed); ?></span>
                        <?php endif; endforeach; ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="card-actions">
                        <a href="update.php?id=<?php echo $budget['id']; ?>" class="btn btn-edit">
                            <i class="fa-solid fa-edit"></i> تعديل
                        </a>
                        <a href="view.php?id=<?php echo $budget['id']; ?>" class="btn btn-secondary">
                            <i class="fa-solid fa-eye"></i> عرض التفاصيل
                        </a>
                        <a href="delete.php?id=<?php echo $budget['id']; ?>" 
                           class="btn btn-danger" 
                           onclick="return confirm('هل أنت متأكد من حذف هذه الميزانية؟')">
                            <i class="fa-solid fa-trash"></i> حذف
                        </a>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fa-solid fa-wallet"></i>
                    <h3>لا توجد ميزانيات</h3>
                    <p>ابدأ بإضافة أول ميزانية لك</p>
                    <a href="insert.php" class="btn btn-primary">
                        <i class="fa-solid fa-plus"></i> إضافة ميزانية جديدة
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // تأكيد الحذف
    const deleteButtons = document.querySelectorAll('.btn-danger');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('هل أنت متأكد من الحذف؟ لا يمكن التراجع عن هذا الإجراء.')) {
                e.preventDefault();
            }
        });
    });
    
    // إغلاق رسائل التنبيه تلقائياً
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.5s';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});
</script>
</body>
</html>
<?php mysqli_close($conn); ?>