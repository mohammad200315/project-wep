<?php
// config.php - ملف الإعدادات العامة

// بيئة العمل (development/production)
define('ENVIRONMENT', 'development');

// إعدادات العرض
define('SITE_NAME', 'لوحة تحكم الميزانية');
define('SITE_URL', 'http://localhost/budget_dashboard/');
define('TIMEZONE', 'Asia/Riyadh');

// إعدادات قاعدة البيانات (محددة في db.php)

// إعدادات الأمان
define('SESSION_TIMEOUT', 3600); // ثانية
define('MAX_LOGIN_ATTEMPTS', 5);
define('PASSWORD_MIN_LENGTH', 8);

// إعدادات إضافية
define('SEED_SAMPLE_DATA', true); // إضافة بيانات تجريبية تلقائياً
define('DEBUG_MODE', ENVIRONMENT === 'development');

// تعيين المنطقة الزمنية
date_default_timezone_set(TIMEZONE);

// تفعيل عرض الأخطاء في وضع التطوير فقط
if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// دالة لتحميل الفئات تلقائياً
spl_autoload_register(function ($class_name) {
    $file = __DIR__ . '/classes/' . $class_name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// دالة لتحويل التاريخ العربي
function hijri_date($timestamp = null) {
    $timestamp = $timestamp ?? time();
    // يمكن إضافة مكتبة للتاريخ الهجري هنا
    return date('Y/m/d', $timestamp);
}

// دالة لتنظيف المدخلات
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// دالة للتحقق من الصلاحيات
function has_permission($required_role) {
    if (!isset($_SESSION['user_role'])) {
        return false;
    }
    
    $roles = ['viewer' => 1, 'user' => 2, 'admin' => 3];
    
    $user_level = $roles[$_SESSION['user_role']] ?? 0;
    $required_level = $roles[$required_role] ?? 0;
    
    return $user_level >= $required_level;
}
?>