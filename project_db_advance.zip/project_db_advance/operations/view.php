<?php
// view.php - عرض تفاصيل الميزانية
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// الاتصال بقاعدة البيانات
$host = "localhost";
$username = "root";
$password = "";
$database = "budget_system";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("فشل الاتصال: " . mysqli_connect_error());
}

// جلب ID الميزانية
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id == 0) {
    header('Location: index.php?error=not_found');
    exit();
}

// جلب بيانات الميزانية
$sql = "SELECT * FROM budgets WHERE id = $id";
$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    header('Location: index.php?error=not_found');
    exit();
}

$budget = mysqli_fetch_assoc($result);

// حساب القيم
$progress = $budget['progress'];
$color = $progress >= 80 ? '#dc3545' : ($progress >= 60 ? '#f59e0b' : '#10b981');
$remaining = $budget['total_amount'] - $budget['spent_amount'];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تفاصيل الميزانية</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* نفس الـ CSS الموجود في ملف index.php */
        :root {
            --primary-bg: #f9fafb;
            --white: #ffffff;
            --sidebar-bg: #ffffff;
            --primary-green: #007a5a;
            --dark-green: #00674d;
            --text-primary: #1f2937;
            --text-secondary: #6b7280;
            --text-muted: #9ca3af;
            --border-color: #e5e7eb;
            --light-border: #f3f4f6;
            --progress-green: #10b981;
            --progress-orange: #f59e0b;
            --progress-red: #dc3545;
            --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }
        
        body {
            background: var(--primary-bg);
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .app-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* الشريط الجانبي */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            border-left: 1px solid var(--light-border);
            padding: 32px 24px;
            position: fixed;
            right: 0;
            top: 0;
            bottom: 0;
            overflow-y: auto;
        }
        
        .sidebar-header {
            margin-bottom: 40px;
        }
        
        .sidebar-header h2 {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 4px;
        }
        
        .sidebar-header p {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
        }
        
        .nav-menu {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            text-decoration: none;
            color: var(--text-secondary);
            border-radius: 12px;
            transition: all 0.2s ease;
            font-weight: 500;
            font-size: 15px;
        }
        
        .nav-item i {
            margin-left: 12px;
            width: 20px;
            text-align: center;
            font-size: 16px;
        }
        
        .nav-item.active {
            background: var(--white);
            color: var(--text-primary);
            font-weight: 600;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
        }
        
        .nav-item:hover:not(.active) {
            background: #f8f9fa;
            color: var(--text-primary);
        }
        
        /* المحتوى الرئيسي */
        .main-content {
            flex: 1;
            margin-right: 280px;
            padding: 40px;
            max-width: 1200px;
        }
        
        /* رأس الصفحة */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .page-title h1 {
            font-size: 30px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 8px;
        }
        
        .page-title p {
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            outline: none;
        }
        
        .btn-secondary {
            background: var(--white);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
        }
        
        .btn-secondary:hover {
            border-color: var(--primary-green);
            color: var(--primary-green);
        }
        
        .btn-edit {
            background: var(--progress-orange);
            color: #212529;
        }
        
        .btn-edit:hover {
            background: #e0a800;
        }
        
        .btn-danger {
            background: var(--progress-red);
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        /* بطاقة التفاصيل */
        .detail-card {
            background: var(--white);
            border-radius: 24px;
            padding: 32px;
            border: 1px solid var(--border-color);
        }
        
        .detail-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 32px;
        }
        
        .detail-title h2 {
            font-size: 32px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 4px;
        }
        
        .detail-title p {
            color: var(--text-secondary);
            font-size: 16px;
        }
        
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        
        .status-active {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-completed {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .status-cancelled {
            background: #fee2e2;
            color: #991b1b;
        }
        
        /* أقسام التفاصيل */
        .detail-section {
            margin-bottom: 32px;
            padding-bottom: 24px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .detail-section:last-child {
            border-bottom: none;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 16px;
        }
        
        /* شريط التقدم */
        .progress-info {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .progress-bar {
            height: 8px;
            background: var(--light-border);
            border-radius: 10px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            border-radius: 10px;
        }
        
        /* الشبكات */
        .financial-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        
        .financial-item {
            text-align: center;
            padding: 20px;
            background: var(--light-border);
            border-radius: 12px;
        }
        
        .financial-label {
            display: block;
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }
        
        .financial-value {
            display: block;
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
        }
        
        .dates-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }
        
        .date-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: var(--light-border);
            border-radius: 8px;
        }
        
        .date-label {
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .date-value {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        /* الوسوم */
        .tags-container {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        
        .tag {
            background: var(--light-border);
            border: 1px solid var(--border-color);
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        /* أزرار الإجراءات */
        .detail-actions {
            display: flex;
            gap: 12px;
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid var(--border-color);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .app-container {
                flex-direction: column;
            }
            
            .sidebar {
                position: static;
                width: 100%;
                border-left: none;
                border-bottom: 1px solid var(--light-border);
            }
            
            .main-content {
                margin-right: 0;
                padding: 20px;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 16px;
            }
            
            .header-left, .header-right {
                width: 100%;
            }
            
            .financial-grid {
                grid-template-columns: 1fr;
            }
            
            .dates-grid {
                grid-template-columns: 1fr;
            }
            
            .detail-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
<div class="app-container">
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>إعدادات المنظمة</h2>
            <p>Organization Settings</p>
        </div>
        
        <nav class="nav-menu">
            <a href="index.php" class="nav-item">
                <i class="fa-solid fa-gear"></i>
                <span>عام</span>
            </a>
            
            <a href="#" class="nav-item">
                <i class="fa-solid fa-users"></i>
                <span>الأعضاء</span>
            </a>
            
            <a href="#" class="nav-item">
                <i class="fa-solid fa-briefcase"></i>
                <span>الخبراء</span>
            </a>
            
            <a href="index.php" class="nav-item active">
                <i class="fa-solid fa-dollar-sign"></i>
                <span>الميزانية</span>
            </a>
            
            <a href="#" class="nav-item">
                <i class="fa-solid fa-chart-line"></i>
                <span>التحليلات</span>
            </a>
        </nav>
    </div>
    
    <div class="main-content">
        <div class="page-header">
            <div class="header-left">
                <div class="page-title">
                    <h1>تفاصيل الميزانية</h1>
                    <p><?php echo htmlspecialchars($budget['title']); ?></p>
                </div>
            </div>
            <div class="header-right">
                <a href="index.php" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-right"></i> العودة
                </a>
                <a href="update.php?id=<?php echo $id; ?>" class="btn btn-edit">
                    <i class="fa-solid fa-edit"></i> تعديل
                </a>
            </div>
        </div>

        <div class="detail-card">
            <div class="detail-header">
                <div class="detail-title">
                    <h2>$<?php echo number_format($budget['total_amount']); ?></h2>
                    <p><?php echo htmlspecialchars($budget['title']); ?></p>
                </div>
                <span class="status-badge status-<?php echo $budget['status']; ?>">
                    <?php 
                    $status_text = [
                        'active' => 'نشط',
                        'completed' => 'مكتمل',
                        'cancelled' => 'ملغي'
                    ];
                    echo $status_text[$budget['status']] ?? $budget['status'];
                    ?>
                </span>
            </div>

            <?php if (!empty($budget['description'])): ?>
            <div class="detail-section">
                <h3 class="section-title">الوصف</h3>
                <p><?php echo nl2br(htmlspecialchars($budget['description'])); ?></p>
            </div>
            <?php endif; ?>

            <div class="detail-section">
                <div class="progress-info">
                    <span class="progress-percent" style="color: <?php echo $color; ?>;">
                        <?php echo $progress; ?>%
                    </span>
                    <span>مستوى الإنجاز</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $progress; ?>%; background: <?php echo $color; ?>;"></div>
                </div>
            </div>

            <div class="detail-section">
                <h3 class="section-title">المعلومات المالية</h3>
                <div class="financial-grid">
                    <div class="financial-item">
                        <span class="financial-label">المبلغ الإجمالي</span>
                        <span class="financial-value">$<?php echo number_format($budget['total_amount']); ?></span>
                    </div>
                    <div class="financial-item">
                        <span class="financial-label">المبلغ المنفق</span>
                        <span class="financial-value">$<?php echo number_format($budget['spent_amount']); ?></span>
                    </div>
                    <div class="financial-item">
                        <span class="financial-label">المبلغ المتبقي</span>
                        <span class="financial-value">$<?php echo number_format($remaining); ?></span>
                    </div>
                </div>
            </div>

            <div class="detail-section">
                <h3 class="section-title">التواريخ</h3>
                <div class="dates-grid">
                    <div class="date-item">
                        <span class="date-label">تاريخ البدء</span>
                        <span class="date-value"><?php echo date('M d, Y', strtotime($budget['start_date'])); ?></span>
                    </div>
                    <div class="date-item">
                        <span class="date-label">تاريخ الانتهاء</span>
                        <span class="date-value"><?php echo date('M d, Y', strtotime($budget['end_date'])); ?></span>
                    </div>
                    <div class="date-item">
                        <span class="date-label">تاريخ الإنشاء</span>
                        <span class="date-value"><?php echo date('M d, Y', strtotime($budget['created_at'])); ?></span>
                    </div>
                    <div class="date-item">
                        <span class="date-label">آخر تحديث</span>
                        <span class="date-value"><?php echo date('M d, Y', strtotime($budget['updated_at'])); ?></span>
                    </div>
                </div>
            </div>

            <?php if (!empty($budget['tags'])): 
                $tags = explode(',', $budget['tags']);
            ?>
            <div class="detail-section">
                <h3 class="section-title">الوسوم</h3>
                <div class="tags-container">
                    <?php foreach ($tags as $tag): 
                        $tag_trimmed = trim($tag);
                        if (!empty($tag_trimmed)):
                    ?>
                    <span class="tag"><?php echo htmlspecialchars($tag_trimmed); ?></span>
                    <?php endif; endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="detail-actions">
                <a href="update.php?id=<?php echo $id; ?>" class="btn btn-edit">
                    <i class="fa-solid fa-edit"></i> تعديل الميزانية
                </a>
                <a href="delete.php?id=<?php echo $id; ?>" 
                   class="btn btn-danger" 
                   onclick="return confirm('هل أنت متأكد من حذف هذه الميزانية؟')">
                    <i class="fa-solid fa-trash"></i> حذف الميزانية
                </a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php mysqli_close($conn); ?>