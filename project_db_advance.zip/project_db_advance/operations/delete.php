<?php
// delete.php - حذف ميزانية (معدّل)
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// الاتصال بقاعدة البيانات
$host = "localhost";
$username = "root";
$password = "";
$database = "budget_system";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("فشل الاتصال: " . mysqli_connect_error());
}

// جلب ID الميزانية
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id == 0) {
    header('Location: index.php?error=not_found');
    exit();
}

// التحقق من وجود الميزانية
$check_sql = "SELECT id FROM budgets WHERE id = $id";
$check_result = mysqli_query($conn, $check_sql);

if (!$check_result || mysqli_num_rows($check_result) == 0) {
    header('Location: index.php?error=not_found');
    exit();
}

// حذف الميزانية
$delete_sql = "DELETE FROM budgets WHERE id = $id";

if (mysqli_query($conn, $delete_sql)) {
    header('Location: index.php?success=delete');
    exit();
} else {
    header('Location: index.php?error=delete_failed&message=' . urlencode(mysqli_error($conn)));
    exit();
}

mysqli_close($conn);
?>