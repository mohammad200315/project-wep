<?php
// insert.php - إضافة ميزانية جديدة (معدّل)
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// الاتصال بقاعدة البيانات
$host = "localhost";
$username = "root";
$password = "";
$database = "budget_system";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("فشل الاتصال: " . mysqli_connect_error());
}

$error = '';

// معالجة النموذج عند الإرسال
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // تنظيف المدخلات
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $total_amount = floatval($_POST['total_amount']);
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $tags = mysqli_real_escape_string($conn, $_POST['tags']);
    
    // التحقق من البيانات
    if (empty($title) || $total_amount <= 0 || empty($start_date) || empty($end_date)) {
        $error = 'جميع الحقول المطلوبة يجب ملؤها';
    } elseif ($end_date < $start_date) {
        $error = 'تاريخ الانتهاء يجب أن يكون بعد تاريخ البدء';
    } else {
        // حساب القيم
        $spent_amount = 0;
        $progress = 0;
        $status = 'active';
        
        // إضافة الميزانية
        $sql = "INSERT INTO budgets (title, description, total_amount, spent_amount, 
                start_date, end_date, progress, status, tags) 
                VALUES ('$title', '$description', $total_amount, $spent_amount,
                '$start_date', '$end_date', $progress, '$status', '$tags')";
        
        if (mysqli_query($conn, $sql)) {
            // إعادة التوجيه مع رسالة نجاح
            header('Location: index.php?success=insert');
            exit();
        } else {
            $error = 'فشل إضافة الميزانية: ' . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة ميزانية جديدة</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* نفس الـ CSS الموجود في ملف update.php */
        :root {
            --primary-bg: #f9fafb;
            --white: #ffffff;
            --sidebar-bg: #ffffff;
            --primary-green: #007a5a;
            --dark-green: #00674d;
            --text-primary: #1f2937;
            --text-secondary: #6b7280;
            --text-muted: #9ca3af;
            --border-color: #e5e7eb;
            --light-border: #f3f4f6;
            --progress-green: #10b981;
            --progress-orange: #f59e0b;
            --progress-red: #dc3545;
            --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }
        
        body {
            background: var(--primary-bg);
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        .app-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* الشريط الجانبي */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            border-left: 1px solid var(--light-border);
            padding: 32px 24px;
            position: fixed;
            right: 0;
            top: 0;
            bottom: 0;
            overflow-y: auto;
        }
        
        .sidebar-header {
            margin-bottom: 40px;
        }
        
        .sidebar-header h2 {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 4px;
        }
        
        .sidebar-header p {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
        }
        
        .nav-menu {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            text-decoration: none;
            color: var(--text-secondary);
            border-radius: 12px;
            transition: all 0.2s ease;
            font-weight: 500;
            font-size: 15px;
        }
        
        .nav-item i {
            margin-left: 12px;
            width: 20px;
            text-align: center;
            font-size: 16px;
        }
        
        .nav-item.active {
            background: var(--white);
            color: var(--text-primary);
            font-weight: 600;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
        }
        
        .nav-item:hover:not(.active) {
            background: #f8f9fa;
            color: var(--text-primary);
        }
        
        /* المحتوى الرئيسي */
        .main-content {
            flex: 1;
            margin-right: 280px;
            padding: 40px;
            max-width: 800px;
        }
        
        /* رأس الصفحة */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .page-title h1 {
            font-size: 30px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 8px;
        }
        
        .page-title p {
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            outline: none;
        }
        
        .btn-secondary {
            background: var(--white);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
        }
        
        .btn-secondary:hover {
            border-color: var(--primary-green);
            color: var(--primary-green);
        }
        
        /* نموذج الإضافة */
        .form-container {
            background: var(--white);
            border-radius: 24px;
            padding: 32px;
            border: 1px solid var(--border-color);
        }
        
        .form-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 8px;
        }
        
        .form-description {
            color: var(--text-secondary);
            font-size: 14px;
            margin-bottom: 32px;
        }
        
        .form-group {
            margin-bottom: 24px;
        }
        
        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 8px;
        }
        
        .form-label.required::after {
            content: " *";
            color: var(--progress-red);
        }
        
        .form-input,
        .form-textarea,
        .form-select {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            color: var(--text-primary);
            background: var(--white);
            transition: border 0.2s;
        }
        
        .form-input:focus,
        .form-textarea:focus,
        .form-select:focus {
            outline: none;
            border-color: var(--primary-green);
            box-shadow: 0 0 0 3px rgba(0, 122, 90, 0.1);
        }
        
        .form-textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        
        /* رسائل الخطأ */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-error {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #991b1b;
        }
        
        /* أزرار الإجراءات */
        .btn-primary {
            background: var(--primary-green);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--dark-green);
        }
        
        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid var(--border-color);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .app-container {
                flex-direction: column;
            }
            
            .sidebar {
                position: static;
                width: 100%;
                border-left: none;
                border-bottom: 1px solid var(--light-border);
            }
            
            .main-content {
                margin-right: 0;
                padding: 20px;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 16px;
            }
            
            .header-left, .header-right {
                width: 100%;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
<div class="app-container">
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>إعدادات المنظمة</h2>
            <p>Organization Settings</p>
        </div>
        
        <nav class="nav-menu">
            <a href="index.php" class="nav-item">
                <i class="fa-solid fa-gear"></i>
                <span>عام</span>
            </a>
            
            <a href="#" class="nav-item">
                <i class="fa-solid fa-users"></i>
                <span>الأعضاء</span>
            </a>
            
            <a href="#" class="nav-item">
                <i class="fa-solid fa-briefcase"></i>
                <span>الخبراء</span>
            </a>
            
            <a href="index.php" class="nav-item active">
                <i class="fa-solid fa-dollar-sign"></i>
                <span>الميزانية</span>
            </a>
            
            <a href="#" class="nav-item">
                <i class="fa-solid fa-chart-line"></i>
                <span>التحليلات</span>
            </a>
        </nav>
    </div>
    
    <div class="main-content">
        <div class="page-header">
            <div class="header-left">
                <div class="page-title">
                    <h1>إضافة ميزانية جديدة</h1>
                    <p>املأ النموذج لإضافة ميزانية جديدة</p>
                </div>
            </div>
            <div class="header-right">
                <a href="index.php" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-right"></i> العودة
                </a>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fa-solid fa-exclamation-triangle"></i>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" action="">
                <div class="form-group">
                    <label for="title" class="form-label required">عنوان الميزانية</label>
                    <input type="text" id="title" name="title" class="form-input" required 
                           placeholder="مثال: مصمم منتجات (Product Designer)" 
                           value="<?php echo $_POST['title'] ?? ''; ?>">
                </div>

                <div class="form-group">
                    <label for="description" class="form-label">الوصف</label>
                    <textarea id="description" name="description" class="form-textarea" 
                              placeholder="وصف تفصيلي للميزانية..."><?php echo $_POST['description'] ?? ''; ?></textarea>
                </div>

                <div class="form-group">
                    <label for="total_amount" class="form-label required">المبلغ الإجمالي ($)</label>
                    <input type="number" id="total_amount" name="total_amount" class="form-input" 
                           min="0" step="0.01" required 
                           placeholder="مثال: 520000" 
                           value="<?php echo $_POST['total_amount'] ?? ''; ?>">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="start_date" class="form-label required">تاريخ البدء</label>
                        <input type="date" id="start_date" name="start_date" class="form-input" required 
                               value="<?php echo $_POST['start_date'] ?? date('Y-m-d'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="end_date" class="form-label required">تاريخ الانتهاء</label>
                        <input type="date" id="end_date" name="end_date" class="form-input" required 
                               value="<?php echo $_POST['end_date'] ?? date('Y-m-d', strtotime('+1 year')); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="tags" class="form-label">الوسوم (مفصولة بفواصل)</label>
                    <input type="text" id="tags" name="tags" class="form-input" 
                           placeholder="مثال: UI/UX Designer, Visual Designer, +7 سنوات خبرة"
                           value="<?php echo $_POST['tags'] ?? ''; ?>">
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fa-solid fa-save"></i> حفظ الميزانية
                    </button>
                    <a href="index.php" class="btn btn-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const startDate = document.getElementById('start_date');
    const endDate = document.getElementById('end_date');
    
    // تعيين القيم الافتراضية إذا كانت فارغة
    if (!startDate.value) {
        startDate.value = new Date().toISOString().split('T')[0];
    }
    
    if (!endDate.value) {
        const nextYear = new Date();
        nextYear.setFullYear(nextYear.getFullYear() + 1);
        endDate.value = nextYear.toISOString().split('T')[0];
    }
    
    // التحقق من التواريخ
    startDate.addEventListener('change', function() {
        if (this.value > endDate.value) {
            endDate.value = this.value;
        }
    });
    
    endDate.addEventListener('change', function() {
        if (this.value < startDate.value) {
            alert('تاريخ الانتهاء يجب أن يكون بعد تاريخ البدء');
            this.value = startDate.value;
        }
    });
});
</script>
</body>
</html>
<?php mysqli_close($conn); ?>