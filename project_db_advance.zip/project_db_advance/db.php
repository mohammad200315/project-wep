<?php
// db.php - مبسط
session_start();

// إعدادات الاتصال
$host = "localhost";
$username = "root";
$password = "";
$database = "budget_db";

// إنشاء الاتصال
$conn = mysqli_connect($host, $username, $password);

if (!$conn) {
    die("فشل الاتصال: " . mysqli_connect_error());
}

// إنشاء قاعدة البيانات
$create_db = "CREATE DATABASE IF NOT EXISTS $database 
              CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
mysqli_query($conn, $create_db);
mysqli_select_db($conn, $database);

// إنشاء جدول الميزانيات
$create_table = "CREATE TABLE IF NOT EXISTS budgets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    total_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    spent_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    progress INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active',
    tags TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (!mysqli_query($conn, $create_table)) {
    die("خطأ في إنشاء الجدول: " . mysqli_error($conn));
}

mysqli_set_charset($conn, "utf8mb4");

// ==================== دوال CRUD ====================

function get_all_budgets() {
    global $conn;
    $sql = "SELECT * FROM budgets ORDER BY created_at DESC";
    return mysqli_query($conn, $sql);
}

function get_budget($id) {
    global $conn;
    $id = intval($id);
    $sql = "SELECT * FROM budgets WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    return $result ? mysqli_fetch_assoc($result) : null;
}

function insert_budget($data) {
    global $conn;
    
    $title = mysqli_real_escape_string($conn, $data['title']);
    $description = mysqli_real_escape_string($conn, $data['description'] ?? '');
    $total_amount = floatval($data['total_amount']);
    $spent_amount = floatval($data['spent_amount'] ?? 0);
    $start_date = mysqli_real_escape_string($conn, $data['start_date']);
    $end_date = mysqli_real_escape_string($conn, $data['end_date']);
    $tags = mysqli_real_escape_string($conn, $data['tags'] ?? '');
    
    // حساب التقدم
    $progress = $total_amount > 0 ? min(100, intval(($spent_amount / $total_amount) * 100)) : 0;
    
    $sql = "INSERT INTO budgets (title, description, total_amount, spent_amount, 
            start_date, end_date, progress, tags) 
            VALUES ('$title', '$description', $total_amount, $spent_amount,
            '$start_date', '$end_date', $progress, '$tags')";
    
    if (mysqli_query($conn, $sql)) {
        return mysqli_insert_id($conn);
    }
    return false;
}

function update_budget($id, $data) {
    global $conn;
    $id = intval($id);
    
    $title = mysqli_real_escape_string($conn, $data['title']);
    $description = mysqli_real_escape_string($conn, $data['description'] ?? '');
    $total_amount = floatval($data['total_amount']);
    $spent_amount = floatval($data['spent_amount'] ?? 0);
    $start_date = mysqli_real_escape_string($conn, $data['start_date']);
    $end_date = mysqli_real_escape_string($conn, $data['end_date']);
    $tags = mysqli_real_escape_string($conn, $data['tags'] ?? '');
    $status = mysqli_real_escape_string($conn, $data['status'] ?? 'active');
    
    // حساب التقدم
    $progress = $total_amount > 0 ? min(100, intval(($spent_amount / $total_amount) * 100)) : 0;
    
    $sql = "UPDATE budgets SET 
            title = '$title',
            description = '$description',
            total_amount = $total_amount,
            spent_amount = $spent_amount,
            start_date = '$start_date',
            end_date = '$end_date',
            progress = $progress,
            status = '$status',
            tags = '$tags'
            WHERE id = $id";
    
    return mysqli_query($conn, $sql);
}

function delete_budget($id) {
    global $conn;
    $id = intval($id);
    $sql = "DELETE FROM budgets WHERE id = $id";
    return mysqli_query($conn, $sql);
}

// إضافة بيانات تجريبية
$check = mysqli_query($conn, "SELECT COUNT(*) as count FROM budgets");
if ($check) {
    $row = mysqli_fetch_assoc($check);
    if ($row['count'] == 0) {
        // بيانات تجريبية من الصورة
        $sample_data = [
            [
                'title' => 'Product Designer',
                'description' => 'مصمم منتجات',
                'total_amount' => 520000,
                'spent_amount' => 312000,
                'start_date' => '2024-05-31',
                'end_date' => '2024-12-31',
                'tags' => 'UI/UX Designer, Visual Designer, Design Lead, +7 سنوات خبرة'
            ],
            [
                'title' => 'Human Resources',
                'description' => 'الموارد البشرية',
                'total_amount' => 120000,
                'spent_amount' => 34500,
                'start_date' => '2024-05-31',
                'end_date' => '2024-12-31',
                'tags' => 'HR, Recruitment, Training'
            ]
        ];
        
        foreach ($sample_data as $data) {
            insert_budget($data);
        }
    }
}
?>